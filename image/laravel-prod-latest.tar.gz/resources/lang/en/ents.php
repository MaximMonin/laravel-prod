<?php

return [
    'Sumy' => 'Sumy Dairy Plant',
    'Chernigov' => 'Chernihiv Dairy Plant',
];

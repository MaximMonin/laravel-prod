<div class="row">
    <div class="col-sm-6">
	<div class="contacts-text">
	    <div class="text">
	    <p>
		<b>Milkiland Ukraine</b> is a member of the Milkiland N.V. international group of companies and is one of the leading milk processors and dairy producers and exporters in Ukraine.
	    </p>	
        </div>
    </div>
    <div class="contacts-info-row">
      <div class="row">
	<div class="pnone-block col-sm-6">
	    <h4>Phone:</h4>
 	    <p class="phone">
		<span>+38 (044) 369-52-00</span>
	    </p>
	</div>
	<div class="email-block col-sm-6">
	    <h4>Email:</h4>
	    <p class="e-mail">
		<span>admin@milkiland.com</span>
	    </p>
	</div>
    </div>
    <div class="row">
	<div class="address-block col-sm-6">
	    <h4>Address:</h4>
	    <p class="address">
		9 Borispolskaya St.,<br> 
		Kyiv, Ukraine 02099
	    </p>
	</div>
    </div>
</div>
</div>
    <div class="col-sm-6">
	<div class="map">
	    <img src="/images/milkiland_map.png" width=100%>
	</div>
    </div>
</div>

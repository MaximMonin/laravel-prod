<div class="row">
    <div class="col-sm-6">
	<div class="contacts-text">
	    <div class="text">
	    <p>
		<b>ТОВ "Милкиленд Украина"</b> является членом международной группы компаний Милкиленд Н.В. и входит в пятерку ведущих переработчиков молока и производителей и экспортеров молочной продукции в Украине. Компания управляет 10 молокоперерабатывающими заводами, расположенными в экологически чистых 6 областях страны.
	    </p>	
        </div>
    </div>
    <div class="contacts-info-row">
      <div class="row">
	<div class="pnone-block col-sm-6">
	    <h4>Телефон:</h4>
 	    <p class="phone">
		<span>+38 (044) 369-52-00</span>
	    </p>
	</div>
	<div class="email-block col-sm-6">
	    <h4>Email:</h4>
	    <p class="e-mail">
		<span>admin@milkiland.com</span>
	    </p>
	</div>
    </div>
    <div class="row">
	<div class="address-block col-sm-6">
	    <h4>Адрес:</h4>
	    <p class="address">
		02099, г. Киев,<br> 
		Бориспольская, 9
	    </p>
	</div>
    </div>
</div>
</div>
    <div class="col-sm-6">
	<div class="map">
	    <img src="/images/milkiland_map.png" width=100%>
	</div>
    </div>
</div>

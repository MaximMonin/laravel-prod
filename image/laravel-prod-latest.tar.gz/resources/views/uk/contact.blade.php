<div class="row">
    <div class="col-sm-6">
	<div class="contacts-text">
	    <div class="text">
	    <p>
		<b>ТОВ "Мілкіленд Україна"</b> є членом міжнародної групи компаній Мілкіленд Н.В. і входить в п'ятірку провідних переробників молока і виробників і експортерів молочної продукції в Україні. Компанія управляє 10 молокопереробними заводами, розташованими в екологічно чистих 6 областях країни.
	    </p>	
        </div>
    </div>
    <div class="contacts-info-row">
      <div class="row">
	<div class="pnone-block col-sm-6">
	    <h4>Телефон:</h4>
 	    <p class="phone">
		<span>+38 (044) 369-52-00</span>
	    </p>
	</div>
	<div class="email-block col-sm-6">
	    <h4>Email:</h4>
	    <p class="e-mail">
		<span>admin@milkiland.com</span>
	    </p>
	</div>
    </div>
    <div class="row">
	<div class="address-block col-sm-6">
	    <h4>Адреса:</h4>
	    <p class="address">
		02099, м. Киев,<br> 
		Бориспільска, 9
	    </p>
	</div>
    </div>
</div>
</div>
    <div class="col-sm-6">
	<div class="map">
	    <img src="/images/milkiland_map.png" width=100%>
	</div>
    </div>
</div>
